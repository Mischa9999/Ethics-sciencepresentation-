# Wer drückt ab? – Präsentation

Drohnen und KI-gestützte Kriegsführung, technisch und ethisch betrachtet (Seminar Ethik und Wissenschaft).

## Lokal auf dem Laptop
`index.html` doppelklicken. Läuft ohne Internet. Der Service Worker wird lokal absichtlich nicht gestartet.

## Auf GitHub Pages
1. Alle Dateien dieses Ordners in ein Repository hochladen (oberste Ebene).
2. Repository → Settings → Pages → „Deploy from a branch“, Branch `main`, Ordner `/ (root)`.
3. Nach ca. einer Minute ist die Seite unter `https://<name>.github.io/<repo>/` erreichbar.

## iPad
Seite in Safari öffnen → Teilen → „Zum Home-Bildschirm“. Danach startet sie im Vollbild und funktioniert offline.
**Wichtig:** Vor dem Vortrag einmal mit Internet öffnen, damit alles im Cache liegt.

## Änderungen veröffentlichen
Nach jeder Änderung in `sw.js` die Zeile `const VERSION = "v1.0.0";` hochzählen (z. B. `v1.0.1`).
Beim nächsten Start mit Internet lädt das iPad die neue Version und zeigt oben einen Hinweis zum Aktualisieren.

## Bedienung
| Aktion | Laptop / Klicker | iPad |
|---|---|---|
| Weiter | → ↓ Leertaste Bild↓ Enter | rechts tippen oder nach links wischen |
| Zurück | ← ↑ Bild↑ | links tippen oder nach rechts wischen |
| Sprechernotizen | N | Notiz-Symbol unten rechts |
| Übersicht / Springen | O | Raster-Symbol |
| Vollbild | F | Vollbild-Symbol |
| Referentenansicht (2. Fenster) | P | – |
| Schwarzbild | B oder . | – |
| Timer neu starten | R | in den Notizen auf die Zeit tippen |

Abstimmungen: auf eine Spalte tippen = +1, das Minus korrigiert. Die Zahlen bleiben auch nach Neuladen erhalten.
Alles löschen: Übersicht (O) → „Alle Abstimmungen löschen“.

Name/Datum ändern: in `index.html` nach „Mischa“ suchen.
